﻿using HotelSim.Rooms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    /// <summary>
    /// Represents a staffmember that finds and cleans dirty rooms
    /// </summary>
    class Cleaner : Person
    {   
        /// <summary>
        /// This function does the decision making for cleaners.
        /// They will first find a dirty room then set it to their goal.
        /// IF they have a goal they will move towards it and then clean it.
        /// </summary>
        public override void Act()
        {
            if (_waiting)
            {
                if ((_hotel.Grid[GetPosition().X, GetPosition().Y].AreaType == null))
                {
                    StopWaiting();
                    return;
                }
                else if (!_hotel.Grid[GetPosition().X, GetPosition().Y].AreaType.Equals("ElevatorShaft"))
                {
                    StopWaiting();
                    return;
                }

            }

            if (_hotel.Grid[GetPosition().X, GetPosition().Y].AreaType != null)
            {
                if (_hotel.Grid[GetPosition().X, GetPosition().Y].AreaType.Equals("ElevatorShaft"))
                {
                    _waiting = true;
                    Elevator temp = (Elevator)_hotel.Graph.FindClosest("Elevator", this._hotel.Grid[GetPosition().X, GetPosition().Y], _hotel);
                    temp.CallElevator(this);
                }
            }

            if (Goal == null)
            {
                //Find a target
                Goal = FindDirtyRoom();
                //If we dont find a target
                if (Goal == null)
                {
                    //Move towards the lobby
                    Move(_hotel.Graph.FindClosest("Lobby",_hotel.Grid[Position[0],Position[1]],_hotel));
                }
            }
            //If we have a target
            else if (Goal != null)
            {
                //Clean that target
                Clean(Goal);
            }
        }

        /// <summary>
        /// Finds the closest dirty room and sets it as this cleaners goal
        /// </summary>
        /// <returns></returns>
        private Room FindDirtyRoom()
        {
            //Find the closest diry room
            return _hotel.Graph.FindClosestDirty(_hotel.Grid[Position[0],Position[1]],_hotel);
        }

        /// <summary>
        /// Cleans a room by one stage
        /// </summary>
        /// <param name="room">Target room</param>
        public void Clean(Room room)
        {
            //If we are at our target
            if (Position == room.Position)
            {
                //if the room is clean add it back to the available rooms and flag it as available
                if (room.Dirtiness == 0 )
                {
                    _hotel.AvailableRooms.Add(room);
                    room.Available = true;
                    Goal = null;
                }
                //If the room is not clean yet make it cleaner by one stage
                else
                {
                    room.Dirtiness--;
                }
            }
            else
            {
                Goal = room;
                Move(room);
                _hotel.AvailableRooms.Remove(room);
            }

            _hotel.AvailableRooms.Add(room);
        }
        
        /// <summary>
        /// Cosntructor
        /// </summary>
        /// <param name="hotel"></param>
        public Cleaner(Hotel hotel)
        {
            _hotel = hotel;
            this.Sprite = new Bitmap(@"../../Resources/Sprites/Cleaner.png");
        }
    }
}
