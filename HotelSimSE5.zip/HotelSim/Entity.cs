﻿using HotelEvents;
using HotelSim.Rooms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    /// <summary>
    /// Base class for everything that resides in the hotel from Rooms to staff
    /// </summary>
    internal abstract class Entity
    {
        public int ID { get; set; }
        protected Hotel _hotel;
        protected PictureBox pictureBox { get; set; }
        public int[] Position { get; set; }
        public Bitmap Sprite { get; set; }

        abstract public void Draw(int width, int height, Form form);

        /// <summary>
        /// Gets a vector containing the position if this enitity
        /// </summary>
        /// <returns></returns>
        public Vector GetPosition()
        {
            //create and return the vector
            return new Vector(Position[0], Position[1]);
        }

        /// <summary>
        /// Calculate the shortest path to destination and move one spot towards it.
        /// </summary>
        /// <param name="destination">The room to move to.</param>
        public void Move(Room destination)
        {
            Room start = null;

            // Null exception catcher.
            if (destination == null)
            {
                return;
            }

            // Find the starting position.
            foreach (Room r in _hotel.Grid)
            {
                if (r.GetPosition().X == GetPosition().X && r.GetPosition().Y == GetPosition().Y)
                    start = r;
            }

            // Stop here if we're at our destination.
            if (start == destination)
            {
                return;
            }

            // Move one spot along the current path.
            if (_hotel.Graph.FindShortestPath(start, destination).Count > 0)
            {
                Position = _hotel.Graph.FindShortestPath(start, destination)[0].Position;
            }

            return;
        }
    }
}
