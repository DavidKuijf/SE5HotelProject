﻿using HotelSim.Rooms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim
{
    //Interface that defines the core of how our factories behave
    interface IEntityFactory
    {
        Hotel Hotel { get; set; }

        /// <summary>
        /// Returns the requested object
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        Entity GetEntity(string type);
    }

    class RoomFactory : IEntityFactory
    {
        public Hotel Hotel { get; set; }

        /// <summary>
        /// Returns the requested room object.
        /// </summary>
        /// <param name="type">The type of the room to create.</param>
        /// <returns></returns>
        public Entity GetEntity(string type)
        {
            switch (type)
            {
                case "Cinema":
                    return new Cinema(Hotel);
                    
                case "Restaurant":
                    return new Restaurant(Hotel);

                case "Room":
                    return new HotelRoom(Hotel);

                case "Fitness":
                    return new Fitness(Hotel);
            }

            return null;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public RoomFactory(Hotel hotel)
        {
            Hotel = hotel;
        }
    }


    class CustomerFactory : IEntityFactory
    {
        public Hotel Hotel { get; set; }

        /// <summary>
        /// Returns the requested customer object.
        /// </summary>
        /// <param name="type">The type of the customer to create.</param>
        /// <returns></returns>
        public Entity GetEntity(string type)
        {
            Entity temp = null;
            temp = new Customer(Hotel);
            temp.Position = new int[] {1, 0};
            return temp;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public CustomerFactory(Hotel hotel)
        {
            Hotel = hotel;
        }
    }

    class CleanerFactory : IEntityFactory
    {
        public Hotel Hotel { get; set; }

        /// <summary>
        /// Returns the requested cleaner object.
        /// </summary>
        /// <param name="type">The type of the cleaner to create.</param>
        /// <returns></returns>
        public Entity GetEntity(string type)
        {
            Entity temp = new Cleaner(Hotel);
            temp.Position = new int[] { 1, 0 };
            return temp;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public CleanerFactory(Hotel hotel)
        {
            Hotel = hotel;
        }
    }
}


