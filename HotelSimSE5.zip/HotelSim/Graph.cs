﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim
{
    class Graph
    {
        // Dictionary that holds the graph. Format: {2, 2}, {{2, 3}, 7}, {{2, 1}, 8}
        Dictionary<Room, Dictionary<Room, int>> Edges = new Dictionary<Room, Dictionary<Room, int>>();

        /// <summary>
        /// Adds an edge to the graph.
        /// </summary>
        /// <param name="name">The name of the node.</param>
        /// <param name="paths">The paths you can take from this node.</param>
        public void AddEdge(Room coord, Dictionary<Room, int> paths)
        {
            Edges[coord] = paths;
        }

        public void RemoveEdge(Room room)
        {
            Edges.Remove(room);
        }

        public Room FindClosest(string areaType, Room currentLocation , Hotel hotel)
        {
           
            List<List<Room>> potentialpaths = new List<List<Room>>();
            List<Room> optimalPath = null;

            foreach (Room item in hotel.Layout)
            {
                if (item.AreaType.Equals(areaType))
                {
                    potentialpaths.Add(FindShortestPath(currentLocation,item));
                }
            }

            int lenght = int.MaxValue;

            foreach (List<Room> item in potentialpaths)
            {
                if (item.Count < lenght)
                {
                    lenght = item.Count;
                    optimalPath = item;
                }
            }

            if (optimalPath == null)
            {
                return currentLocation;
            }
            
            return optimalPath.LastOrDefault();
        }

        public Room FindClosestAvailable(string areaType, Room currentLocation, Hotel hotel)
        {

            List<List<Room>> potentialpaths = new List<List<Room>>();
            List<Room> optimalPath = null;

            foreach (Room item in hotel.Grid)
            {
                if (item.AreaType != null)
                {
                    if (item.AreaType.Equals(areaType) && item.Available)
                    {
                        potentialpaths.Add(FindShortestPath(currentLocation, item));
                    }
                }
                
            }

            int length = int.MaxValue;

            foreach (List<Room> item in potentialpaths)
            {
                if (item.Count < length)
                {
                    length = item.Count;
                    optimalPath = item;
                }
            }

            if (optimalPath == null)
            {
                return null;
            }

            return optimalPath.LastOrDefault();
        }

        public Room FindClosestDirty(Room currentLocation, Hotel hotel)
        {

            List<List<Room>> potentialpaths = new List<List<Room>>();
            List<Room> optimalPath = null;
            foreach (Room item in hotel.Grid)
            {
                if (item.Dirtiness > 0)
                {
                    potentialpaths.Add(FindShortestPath(currentLocation, item));
                }
            }

            int length = int.MaxValue;

            foreach (List<Room> item in potentialpaths)
            {
                if (item.Count < length)
                {
                    length = item.Count;
                    optimalPath = item;
                }
            }

            if (optimalPath == null)
            {
                return null;
            }

            return optimalPath.LastOrDefault();
        }


        public List<Room> FindShortestPath(Room start, Room end)
        {
           
            // List of previous nodes.
            Dictionary<Room, Room> previous = new Dictionary<Room, Room>();
            // List to keep the distances to and from nodes.
            Dictionary<Room, int> distances = new Dictionary<Room, int>();
            // List of all nodes in graph.
            List<Room> nodes = new List<Room>();

            // List of shortest path.
            List<Room> path = null;

            // Set start distance to 0 and distances to all other nodes to infinity (max int value).
            foreach (var edge in Edges)
            {
                if (edge.Key.Equals(start))
                    distances[edge.Key] = 0;
                else
                    distances[edge.Key] = int.MaxValue;

                // Add node to list of nodes in graph.
                nodes.Add(edge.Key);
            }

            // As long as there are nodes to explore do...
            while (nodes.Count != 0)
            {
                // Sort nodes by distance.
                nodes.Sort((i, j) => distances[i] - distances[j]);

                // Set the shortest distance node to smallest.
                Room smallest = nodes[0];

                // If the smallest node is the end, set Path = to the path taken.
                if (smallest.Position == end.Position)
                {
                    path = new List<Room>();
                    while (previous.ContainsKey(smallest))
                    {
                        path.Add(smallest);
                        smallest = previous[smallest];
                    }

                    break;
                }

                // Prevent infitine loops if I goofed up inputting the graph.
                if (distances[smallest] == int.MaxValue)
                {
                    break;
                }

                nodes.Remove(smallest);

                // Walking through all the nodes in order of smallest to longest.
                foreach (var neighbor in Edges[smallest])
                {
                    var alt = distances[smallest] + neighbor.Value;
                    if (alt < distances[neighbor.Key])
                    {
                        distances[neighbor.Key] = alt;
                        previous[neighbor.Key] = smallest;
                    }
                }
            }

            
            List<Room> invertedPath = new List<Room>();

            if (path != null)
            {

                for (int i = path.Count - 1; i >= 0; i--)
                {
                    invertedPath.Add(path[i]);
                }


            }
            if (invertedPath.Count == 0)
            {

            }
            return invertedPath;


        }
    }
}
