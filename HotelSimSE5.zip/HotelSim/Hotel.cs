﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HotelSim.Rooms;
using Newtonsoft.Json;
namespace HotelSim
{
    internal class Hotel
    {
        public readonly Form _form;
        public List<Entity> Layout { get; private set; }
        public List<Room> AvailableRooms { get; }
        public List<Entity> CustomerList { get; }
        public List<Entity> StaffList { get; set; }

        public bool Safe { get; set; }

        public int hotelWidthInPixels { get; set; }
        public int hotelHeightInPixels { get; set; }
        private int HotelHeight { get; set; }
        private int HotelWidth { get; set; }

        public Vector ImageSize { get; set; }
        public Graph Graph { get; private set; }
        public Room[,] Grid { get; private set; }
        public int Cleaningtime { get; internal set; }
        public int Eatingtime { get; internal set; }
        public int Cinematime { get; internal set; }

        public Elevator Elevator { get; private set; }

        /// <summary>
        /// Initiates the hotel. Reads the layoutfile and then adds lobby, elevator and stairs putting all rooms generated in Layout
        /// </summary>
        void HotelInit()
        {
            //make the factory
            RoomFactory roomFactory = new RoomFactory(this);


            //specify the folder where the layout file is located 
            string layoutstring = System.IO.File.ReadAllText(@"../../Resources/Hotel.layout");

            //make a list for temporary objects and deserialize the json into these objects
            List<TempRoom> temp = new List<TempRoom>();
            temp = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TempRoom>>(layoutstring);

            foreach (TempRoom item in temp)
            {
                //For each room in the temporary array create an appropriate room object and add it to the layout
                Room temproom = (Room)roomFactory.GetEntity(item.AreaType);
                Layout.Add(temproom);

                //Parse the Room ID
                temproom.ID = item.ID;
                //parse the position
                string[] splitposition = item.Position.Split(',');
                temproom.Position = new int[] { int.Parse(splitposition[0]), int.Parse(splitposition[1]) };

                string[] splitdimension = item.Dimension.Split(',');
                temproom.Dimension = new int[] { int.Parse(splitdimension[0]), int.Parse(splitdimension[1]) };

                //set the capacity where appropriate
                temproom.Capacity = item.Capacity;

                //if the classification is not null set it and select the appropriate sprite
                if (item.Classification != null)
                {
                    temproom.AreaType = item.Classification.Split(' ')[0]+ item.Classification.Split(' ')[1];
                    temproom.Classification = int.Parse(item.Classification.Split(' ')[0]);

                    if (temproom.Classification == 1)
                        temproom.Sprite = new Bitmap(@"../../Resources/Sprites/Room1Star.png");
                    if (temproom.Classification == 2)
                        temproom.Sprite = new Bitmap(@"../../Resources/Sprites/Room2Star.png");
                    if (temproom.Classification == 3)
                        temproom.Sprite = new Bitmap(@"../../Resources/Sprites/Room3Star.png");
                    if (temproom.Classification == 4)
                        temproom.Sprite = new Bitmap(@"../../Resources/Sprites/Room4Star.png");
                    if (temproom.Classification == 5)
                        temproom.Sprite = new Bitmap(@"../../Resources/Sprites/Room5Star.png");
                }

                //add it to the list of available rooms
                if (item.AreaType.Equals("Room"))
                {
                    AvailableRooms.Add(temproom);
                }
            }

            Vector dimensions = GetDimensions();

            //add lobby at the bottom
           
            Room tempLobby = new Lobby(this);
            tempLobby.Position = new int[] { 1, 0 };
            Layout.Add(tempLobby);
            

            //add lift on the left and stairs on the right
            for (int i = 0; i <= dimensions.Y; i++)
            {
                Room tempElevatorShaft = new ElevatorShaft(this);
                tempElevatorShaft.Position = new int[] { 0, i };
                tempElevatorShaft.AreaType = "ElevatorShaft";
                Layout.Add(tempElevatorShaft);
                Room tempStairs = new Staircase(this);
                tempStairs.Position = new int[] { dimensions.X + 1, i };
                tempStairs.AreaType = "Stairs";
                Layout.Add(tempStairs);
            }


            Elevator = new Elevator(this);
            Elevator.Position = new int[] { 0, 0 };
            Layout.Add(Elevator);

            //add 2 cleaners
            for (int i = 0; i < 2; i++)
            {
                CleanerFactory cFactory = new CleanerFactory(this);
                Entity tempCleaner = cFactory.GetEntity("");
                this.AddStaff(tempCleaner);
            }
        }

        /// <summary>
        /// Adds a customer to the master customer list.
        /// </summary>
        /// <param name="newCustomer">The customer to add.</param>
        public void AddCustomer(Entity newCustomer)
        {
            CustomerList.Add(newCustomer);
        }

        /// <summary>
        /// Removes a customer from the master customer list.
        /// </summary>
        /// <param name="toBeRemoved">The customer to be removed.</param>
        public void RemoveCustomer(Entity toBeRemoved)
        {
            CustomerList.Remove(toBeRemoved);
        }

        /// <summary>
        /// Adds a staff member to the master staff list.
        /// </summary>
        /// <param name="newStaff">The staff member to add.</param>
        public void AddStaff(Entity newStaff)
        {
            StaffList.Add(newStaff);
        }

        /// <summary>
        /// Removes a staff member from the master staff list.
        /// </summary>
        /// <param name="toBeRemoved">The staff member to remove.</param>
        public void RemoveStaff(Entity toBeRemoved)
        {
            StaffList.Remove(toBeRemoved);
        }

        /// <summary>
        /// Checks a customer in to the target room.
        /// </summary>
        /// <param name="customer">The customer to check in.</param>
        /// <param name="target">The room to check in to.</param>
        public void CheckIn(Customer customer, Room target)
        {
            this.AddCustomer(customer);
            AvailableRooms.Remove(target);
            target.Available = false;
        }

        /// <summary>
        /// Checks the customer out of the target room.
        /// </summary>
        /// <param name="customer">The customer to check out.</param>
        /// <param name="target">The room to check out from.</param>
        public void CheckOut(Customer customer, Room target)
        {
            this.RemoveCustomer(customer);
            AvailableRooms.Add(target);
        }

        /// <summary>
        /// Returns the dimensions of the hotel.
        /// </summary>
        /// <returns>The hotel dimensions as int</returns>
        public Vector GetDimensions()
        {
            // Variables to store the maximum sizes of the hotel.
            HotelWidth = 0;
            HotelHeight = 0;

            // Finding the maximum sizes so we can find the amount of pixels we're gonna need to draw it.
            foreach (Room r in Layout)
            {
                if (r.GetPosition().X > HotelWidth)
                    HotelWidth = r.GetPosition().X;
                if (r.GetPosition().Y > HotelHeight)
                    HotelHeight = r.GetPosition().Y;
            }
            return new Vector(HotelWidth, HotelHeight);
        }

        /// <summary>
        /// Draws each room on the screen.
        /// </summary>
        public void Draw()
        {
            Vector dimensions = GetDimensions();

            // Getting the amount of pixels we need.
            hotelWidthInPixels = dimensions.X * ImageSize.X;
            hotelHeightInPixels = dimensions.Y * ImageSize.Y;

            // Draw each room on the screen.
            foreach (Room r in Layout)
            {
                if (!r.AreaType.Equals("Elevator"))
                    r.Draw(hotelWidthInPixels, hotelHeightInPixels, _form);
            }

            foreach (Room r in Layout)
            {
                if (r.GetPosition() == new Vector(0,0))
                {
                    r.Draw(hotelWidthInPixels, hotelHeightInPixels, _form);
                }
            }
        }

        /// <summary>
        /// Creates a graph of the rooms and their connections.
        /// </summary>
        private void CreateGraph()
        {
            Graph = new Graph();

            // Getting the actual hotel width and height. (Basically including the lift, stairs and lobby).
            int actualHotelWidth = this.GetDimensions().X + 1;
            int actualHotelHeight = this.GetDimensions().Y + 1;
            
            // 2D array of rooms to track positions.
            Grid = new Room[actualHotelWidth, actualHotelHeight];

            // The movement weight of each stair node.
            int stairsWeight = 2;

            // Add all te existing (from the layout file) rooms to the grid at their correct positions.
            foreach (Room r in Layout)
            {
                if (!r.AreaType.Equals("Elevator"))
                    Grid[r.GetPosition().X, r.GetPosition().Y] = r;
            }

            // Fill all the empty spots with dummy rooms.
            for (int i = 0; i < Grid.GetLength(0); i++)
            {
                for (int j = 0; j < Grid.GetLength(1); j++)
                {
                    if (Grid[i, j] == null)
                    {
                        Grid[i, j] = new Room(this);
                        Grid[i, j].Position = new int[] { i, j };
                    }
                }
            }
            
            // Setting all the nodes in the graph with their connections to other nodes.
            foreach (Room r in Grid)
            {
                if (r.GetPosition().X < actualHotelWidth - 1 && r.GetPosition().Y < actualHotelHeight)
                {
                    // Not on either edge.
                    if (r.GetPosition().X > 0 && r.GetPosition().Y >= 0)
                    {
                        Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                            new Dictionary<Room, int>()
                            { { Grid[r.GetPosition().X - 1, r.GetPosition().Y], 1 },
                              { Grid[r.GetPosition().X + 1, r.GetPosition().Y], 1 } });
                    }
                    // Left edge.
                    else
                    {
                        Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                            new Dictionary<Room, int>()
                            { { Grid[r.GetPosition().X + 1, r.GetPosition().Y], 1 },
                              { Elevator, this.HotelHeight } });
                    }
                }

                // Right edge.
                else if (r.GetPosition().X >= 0 && r.GetPosition().Y >= 0)
                {
                    if (r.AreaType.Equals("Stairs"))
                    {
                        // Bottom
                        if (r.GetPosition().Y == 0)
                        {
                            Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                                    new Dictionary<Room, int>()
                                    { { Grid[r.GetPosition().X - 1, r.GetPosition().Y], stairsWeight },
                                      { Grid[r.GetPosition().X, r.GetPosition().Y + 1], stairsWeight }});
                        }

                        // Top
                        else if (r.GetPosition().Y >= actualHotelHeight - 1)
                        {
                            Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                                    new Dictionary<Room, int>()
                                    { { Grid[r.GetPosition().X - 1, r.GetPosition().Y], stairsWeight },
                                      { Grid[r.GetPosition().X, r.GetPosition().Y - 1], stairsWeight }});
                        }
                        else
                        {
                            Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                                    new Dictionary<Room, int>()
                                    { { Grid[r.GetPosition().X - 1, r.GetPosition().Y], stairsWeight },
                                      { Grid[r.GetPosition().X, r.GetPosition().Y - 1], stairsWeight },
                                      { Grid[r.GetPosition().X, r.GetPosition().Y + 1], stairsWeight } });
                        }
                    }
                    else
                    {
                        Graph.AddEdge(Grid[r.GetPosition().X, r.GetPosition().Y],
                                new Dictionary<Room, int>()
                                { { Grid[r.GetPosition().X - 1, r.GetPosition().Y], 1 } });
                    }
                }
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="form">The main form of the application.</param>
        public Hotel(Form form)
        {
            ImageSize = new Vector(134, 100);
            _form = form;
            Layout = new List<Entity>();
            AvailableRooms = new List<Room>();
            CustomerList = new List<Entity>();
            StaffList = new List<Entity>();


            Cleaningtime = 5;
            Safe = true;

            HotelInit();

            Draw();

            CreateGraph();

            Cleaningtime = 5;
            Eatingtime = 5;
            Cinematime = 5;
        }
    }
}