﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HotelEvents;
using HotelSim.Rooms;

namespace HotelSim
{
    public partial class MainForm : Form
    {
        private int _time;
        private Hotel _simHotel;
        private bool _paused;
        private StatisticsForm _statisticsForm;
        
        /// <summary>
        /// Pauses and unpauses the simulation.
        /// </summary>
        public void PausePlay()
        {
            // If the simulation isn't paused, pause it. If the simulation is paused, unpause it.
            if (!_paused)
            {
                MainTimer.Stop();
                _paused = true;
                HotelEventManager.Pauze();
            }
            else
            {
                MainTimer.Start();
                _paused = false;
                HotelEventManager.Pauze();
            }
        }

        
        private void Timer_Tick(object sender, EventArgs e)
        {
            _time++;
           

            this.DoUpdate();
        }

        /// <summary>
        /// Calls the act/work/draw functions for all entities every tick.
        /// </summary>
        private void DoUpdate()
        {
            foreach (Room item in _simHotel.Layout)
            {
                item.Work();
                _simHotel.Elevator.Draw(_simHotel.ImageSize.X, _simHotel.ImageSize.Y, this);
            }
            // Draw/act for all customers active in the hotel.
            if (_simHotel.CustomerList.Count!=0)
            {  

                for (int i = _simHotel.CustomerList.Count; i > 0; i--)
                {
                    Customer temp = (Customer)_simHotel.CustomerList[i-1];
                    temp.Draw(_simHotel.ImageSize.X, _simHotel.ImageSize.Y, this);
                    temp.Act();
                    temp.Draw(_simHotel.ImageSize.X, _simHotel.ImageSize.Y, this);
                }
            }

            // Draw/act for all the members of staff active in the hotel.
            foreach (Cleaner item in _simHotel.StaffList)
            {
                item.Act();
                item.Draw(_simHotel.ImageSize.X, _simHotel.ImageSize.Y, this);
            }

            foreach (Room item in _simHotel.Layout)
            {
                item.Work();
            }

            // Updates the text on the statistics form.
            _statisticsForm.DoUpdate();
            
        }

        private void MainForm_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            switch (e.KeyCode)
            {
                // Pause.
                case Keys.P:
                    PausePlay();
                    break;
                // Increase speed.
                case Keys.A:
                    Accelerate();
                    break;
                // Decrease speed.
                case Keys.D:
                    Decelerate();
                    break;
                // Settings.
                case Keys.S:
                    Settings();
                    break;
                // Default speed.
                case Keys.Space:
                    MainTimer.Interval = 1000;
                    HotelEventManager.HTE_Factor = 1;
                    break;
                // Statistics.
                case Keys.Y:
                    _statisticsForm.Show();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Opens the settings window and pauses play whilst it's open.
        /// </summary>
        private void Settings()
        {
            Form settingWindows = new SettingsForm(this , _simHotel);
            settingWindows.Show();
            PausePlay();
        }

        /// <summary>
        /// Slows the speed of the simulation.
        /// </summary>
        private void Decelerate()
        {
            if (HotelEventManager.HTE_Factor >= 1)
            {
                HotelEventManager.HTE_Factor = HotelEventManager.HTE_Factor - 1f ;
                MainTimer.Interval = (int)((1f / HotelEventManager.HTE_Factor) * 1000f);
            }
           
        }

        /// <summary>
        /// Increases the speed of the simulation.
        /// </summary>
        private void Accelerate()
        {
             HotelEventManager.HTE_Factor = HotelEventManager.HTE_Factor + 1f;
             MainTimer.Interval = (int)((1f / HotelEventManager.HTE_Factor) * 1000f);
        }

        /// <summary>
        /// Syncs the program time with the DLL time.
        /// </summary>
        public void TimeSync()
        {
            MainTimer.Interval = (int)((1f / HotelEventManager.HTE_Factor) * 1000f);
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            _simHotel = new Hotel(this);
            _paused = false;
            MainTimer.Start();
            HotelEventHandler handler = new HotelEventHandler(_simHotel);
            HotelEventManager.HTE_Factor = 1;
            HotelEventManager.Register(handler);
            HotelEventManager.Start();
            _statisticsForm = new StatisticsForm(_simHotel);
        }
    }
}
