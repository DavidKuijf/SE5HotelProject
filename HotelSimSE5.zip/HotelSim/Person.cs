﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    abstract class Person : Entity
    {
        protected bool _waiting { get; set; }

        abstract public void Act();

        public Room Goal;

        /// <summary>
        /// Draws the customer on the screen at their position.
        /// </summary>
        /// <param name="width">The width of the image.</param>
        /// <param name="height">The height of the image.</param>
        /// <param name="form">The form to draw it on.</param>
        public override void Draw(int width, int height, Form form)
        {
            // Create a new picturebox if this instance doesn't have one yet.
            if (pictureBox == null)
            {
                pictureBox = new PictureBox();
            }

            // Set the image to the customer sprite and make the background see-through.
            pictureBox.Image = this.Sprite;
            pictureBox.BackColor = Color.Transparent;

            // Set the position of the picturebox depening on the position of the customer.
            int imageX = width * this.GetPosition().X + 50;
            int imageY = _hotel.hotelHeightInPixels - height * (this.GetPosition().Y) + 30;
            pictureBox.Location = new Point(imageX, imageY);
            pictureBox.Size = new Size(this.Sprite.Width, this.Sprite.Height);

            // Add the picturebox to the form and bring it to the front so we can see it in front of the rooms.
            form.Controls.Add(pictureBox);
            pictureBox.BringToFront();
        }

        public void StartWaiting()
        {
            _waiting = true;
        }

        public void StopWaiting()
        {
            _waiting = false;
        }

        public Person()
        {
            _waiting = false;
        }
    }
}
