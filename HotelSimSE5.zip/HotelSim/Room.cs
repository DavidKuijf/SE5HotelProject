﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    //enum RoomType { OneStar, TwoStar, ThreeStar, FourStar, FiveStar, Cinema, Fitness, Restaurant };

    class Room : Entity
    {
        //public RoomType Type { get; }
        public int Capacity { get; set; }
        public string AreaType { get; set; }
        virtual public List<Customer> Occupants {get; set;}
        public bool Available;
		public int[] Dimension { get; set; }
        public int Classification { get; set; }
        public int Dirtiness { get; internal set; }
        public Queue<Customer> Queue { get; set; }


        //public Person[] Occupant { get; }

        virtual public void Work()
        {
            
        }

        /// <summary>
        /// Draws the room at its position on the screen.
        /// </summary>
        /// <param name="width">Hotel width in pixels.</param>
        /// <param name="height">Hotel height in pixels.</param>
        /// <param name="form">The form to draw on.</param>
        public override void Draw(int width, int height, Form form)
        {
            // Standard room size.
            Vector imageSize = new Vector(134, 100);
            
            pictureBox = new PictureBox();

            // Setting the location of the rooms on the screen depending on their location and dimension.
            int imageX = imageSize.X * this.GetPosition().X;
            int imageY = height - imageSize.Y * (this.GetPosition().Y + (this.GetDimension().Y - 1));
            pictureBox.Location = new Point(imageX, imageY);

            // Setting the size of the image depending on the room's dimensions.
            pictureBox.Size = new Size(this.GetDimension().X * imageSize.X, this.GetDimension().Y * imageSize.Y);

            // Setting the image on screen to the image of this room and making sure it fills the entire picturebox.
            pictureBox.Image = (Image)this.Sprite;
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;

            // Adding the picturebox to the main form.
            form.Controls.Add(pictureBox);

            if (this.AreaType.Equals("Elevator"))
            {
                pictureBox.BringToFront();
            }
        }

        /// <summary>
        /// Returns the dimensions of the room as width by height.
        /// </summary>
        /// <returns>The dimensions of the room as width by height.</returns>
        public Vector GetDimension()
        {
            return new Vector(Dimension[0], Dimension[1]);
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel of the room.</param>
        public Room(Hotel hotel)
        {
            _hotel = hotel;
            Queue = new Queue<Customer>();
            Occupants = new List<Customer>();
            Dimension = new int[] { 1, 1 };
            Available = true;
        }
    }
}
