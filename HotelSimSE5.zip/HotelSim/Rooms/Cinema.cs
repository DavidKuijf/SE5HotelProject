﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim
{
    class Cinema : Room
    {
        private int Timer { get; set; }

        private bool FilmStarted { get; set; }

        /// <summary>
        /// Runs the functionality of the room.
        /// </summary>
        override public void Work()
        {
            // Start and stop the film when needed.
            if (FilmStarted)
            {
                if (Timer < _hotel.Cinematime)
                {
                    Timer++;
                }
                else
                {
                    End();
                }
            }

        }

        /// <summary>
        /// Starts the film.
        /// </summary>
        internal void Start()
        {
            // Empties customers out of the queue until the cinema is full.
            for (int i = 0; i <= Queue.Count; i++)
            {
                if (Queue.Count > 0)
                {
                    Occupants.Add(Queue.Dequeue());
                }
            }

            Available = false;
            FilmStarted = true;
        }

        /// <summary>
        /// Ends the film.
        /// </summary>
        internal void End()
        {
            // Sets the wish to null and removes customers from the cinema so they can continue their business.
            for (int i = Occupants.Count - 1; i >= 0; i--)
            {
                Occupants[i].Wish = null;
                Occupants.Remove(Occupants[i]);
            }

            Available = true;
            FilmStarted = false;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public Cinema(Hotel hotel) : base(hotel)
        {
            Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/Cinema.png");
            AreaType = "Cinema";
            Available = true;
            FilmStarted = false;
        }


    }
}
