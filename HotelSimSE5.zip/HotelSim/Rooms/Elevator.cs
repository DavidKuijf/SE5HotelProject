﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim.Rooms
{

    // many tears were shed over this
    class Elevator : Room
    {
        public Room Goal { get; set; }
        private List<Person> _waitingList {get; set;}
        new private List<Person> Occupants { get; set; }



        public void CallElevator(Person customer)
        {
            if (!_waitingList.Contains(customer))
            {
                _waitingList.Add(customer);
            }
            
        }
        /// <summary>
        /// Pickup all waiting customers on the floor we are on
        /// </summary>
        private void PickUp()
        {
            for (int i = _waitingList.Count()-1 ;  i >= 0; i--)
            {
                //if the waiting customer is on the floor the elevator is on pick it up.
                if (_waitingList[i].GetPosition().Y == GetPosition().Y)
                {
                    Occupants.Add(_waitingList[i]);
                    _waitingList.Remove(_waitingList[i]);
                }
            }         
        }

        /// <summary>
        /// Deposit all occupants than need to be on the cussrent floor
        /// </summary>
        private void Deposit()
        {
            for (int i = Occupants.Count()-1; i >= 0 ; i--)
            {
                //if the elevator is on the correct floor have the customers leave the elevator.
                if (Occupants[i].Goal != null)
                {
                    if (Occupants[i].Goal.GetPosition().Y == GetPosition().Y)
                    {
                        Occupants[i].Move(Occupants[i].Goal);
                        Occupants.Remove(Occupants[i]);

                    }
                }
                
            }
        }
        /// <summary>
        /// 
        /// </summary>
        override public void Work()
        {
            Goal = this.FindGoal();

            if (_hotel.Grid != null)
            {
                Dictionary<Room, int> connections = new Dictionary<Room, int>();

                for (int i = 0; i < _hotel.Grid.GetLength(1); i++)
                {
                    int weight = (1 + Math.Abs(this.GetPosition().Y - i)) * (_hotel.Safe ? 2 : 100);
                    connections.Add(_hotel.Grid[this.GetPosition().X + 1, i], weight);
                }

                _hotel.Graph.RemoveEdge(this);
                
                _hotel.Graph.AddEdge(this, connections);

                if (Goal != this)
                {
                    this.Move();
                    foreach (Person item in Occupants)
                    {
                        item.Move(this);
                    }
                }

                Deposit();
                PickUp();
            }
        }

        public override void Draw(int width, int height, Form form)
        {
            // Standard room size.
            Vector imageSize = new Vector(134, 100);

            // Create a new picturebox if this instance doesn't have one yet.
            if (pictureBox == null)
            {
                pictureBox = new PictureBox();
            }

            // Set the image to the customer sprite and make the background see-through.
            pictureBox.Image = this.Sprite;
            pictureBox.BackColor = Color.Transparent;

            // Set the position of the picturebox depening on the position of the customer.
            int imageX = width * this.GetPosition().X;
            int imageY = _hotel.hotelHeightInPixels - height * this.GetPosition().Y;

            pictureBox.Location = new Point(imageX, imageY);
            pictureBox.Size = new Size(this.GetDimension().X * imageSize.X, this.GetDimension().Y * imageSize.Y);

            // Add the picturebox to the form and bring it to the front so we can see it in front of the rooms.
            form.Controls.Add(pictureBox);
            pictureBox.BringToFront();
        }

        private void Move()
        {
            if (this.GetPosition().Y != Goal.GetPosition().Y)
            {
                if (Goal.GetPosition().Y > this.GetPosition().Y)
                {
                    this.Position[1]++;
                }
                else
                {
                    this.Position[1]--;
                }
            }
        }

        private Room FindGoal()
        {
            int smallestDistance = _hotel.GetDimensions().Y * 10;
            Room closestGoal = null;

            foreach (Person occupant in Occupants)
            {
                int compare = 0;

                // Check which floor is closest.
                if (occupant.Goal != null)
                {
                    if (occupant.Goal.GetPosition().Y > this.GetPosition().Y)
                    {
                        compare = occupant.Goal.GetPosition().Y - this.GetPosition().Y;
                    }
                    if (occupant.Goal.GetPosition().Y < this.GetPosition().Y)
                    {
                        compare = this.GetPosition().Y - occupant.Goal.GetPosition().Y;
                    }

                    if (Math.Abs(compare) < smallestDistance)
                    {
                        closestGoal = occupant.Goal;
                    }
                }
                
            }

            if (closestGoal != null)
            {
                foreach (Room r in _hotel.Layout)
                {
                    if (r.AreaType.Equals("ElevatorShaft"))
                    {
                        if (r.GetPosition().Y == closestGoal.GetPosition().Y)
                        {
                            return r;
                        }
                    }
                }
            }
            if (_waitingList.Count() > 0)
            {
                return _hotel.Grid[_waitingList[0].GetPosition().X, _waitingList[0].GetPosition().Y];
            }
            return this;
        }


        public Elevator(Hotel hotel) : base(hotel)
        {
            this.Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/Elevator.png");
            this.Dimension = new int[] { 1, 1 };
            this.AreaType = "Elevator";
            _hotel = hotel;
            _waitingList = new List<Person>();
            Occupants = new List<Person>();
        }
    }
}
