﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim.Rooms
{
    class ElevatorShaft : Room
    {
        override public void Work()
        {

        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public ElevatorShaft(Hotel hotel) : base(hotel)
        {
            this.Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/ElevatorShaft.png");
            this.Dimension = new int[] { 1, 1 };
            this.AreaType = "ElevatorShaft";
        }
    }
}
