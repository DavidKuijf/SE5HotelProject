﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim.Rooms
{
    class Lobby : Room
    {
        override public void Work()
        {
            // Checks in customers one by one. (One every tick).
            if (Queue.Count != 0)
            {
                Customer client = Queue.Dequeue();
                //int RoomClass = int.Parse(client.Wish.Data.First().Value.Split(' ')[1][0].ToString());
                Room target = _hotel.Graph.FindClosestAvailable(client.Wish.Data.First().Value.Split(' ')[1], this._hotel.Grid[1, 0], _hotel);
                if (target == null)
                {
                    _hotel.CustomerList.Remove(client);
                    client.Die();
                }
                else
                {
                    _hotel.CheckIn(client, target);
                    client.Home = target;
                    client.Wish = null;
                }
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public Lobby(Hotel hotel) : base(hotel)
        {
            this.Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/lobby.png");
            this.Dimension = new int[] { hotel.GetDimensions().X, 1 };
            this.AreaType = "Lobby";
        }
    }
}
