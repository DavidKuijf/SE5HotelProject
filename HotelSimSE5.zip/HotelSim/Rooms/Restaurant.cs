﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim.Rooms
{
    class Restaurant: Room
    {
        override public void Work()
        {
            //If the restaurant isn't full grab someone from the queue
            if (Occupants.Count < Capacity)
            {
                if (Queue.Count > 0)
                {
                    Occupants.Add(Queue.Dequeue());
                }
            }

            // Sets the wish to null and removes customers from the cinema so they can continue their business once they're done here.
            for (int i = Occupants.Count - 1; i >= 0; i--)
            {
                if (Occupants[i].Eat())
                {
                    Occupants[i].Wish = null;
                    Occupants.Remove(Occupants[i]);
                }              
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public Restaurant(Hotel hotel) : base(hotel)
        {
            this.Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/Restaurant.png");
            this.AreaType = "Restaurant";
        }
    }
}
