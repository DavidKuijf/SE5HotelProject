﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim.Rooms
{
    class Staircase : Room
    {
        override public void Work()
        {

        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public Staircase(Hotel hotel) : base(hotel)
        {
            this.Sprite = new System.Drawing.Bitmap(@"../../Resources/Sprites/Staircase.png");
            this.Dimension = new int[] { 1, 1 };
            this.AreaType = "Staircase";
        }
    }
}
