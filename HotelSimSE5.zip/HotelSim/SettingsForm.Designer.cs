﻿namespace HotelSim
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TicksLabel = new System.Windows.Forms.Label();
            this.CinemaTimeLabel = new System.Windows.Forms.Label();
            this.CleaningTimeLabel = new System.Windows.Forms.Label();
            this.EatTimeLabel = new System.Windows.Forms.Label();
            this.TicksTextBox = new System.Windows.Forms.TextBox();
            this.CinemaTimeTextBox = new System.Windows.Forms.TextBox();
            this.CleaningTimeTextBox = new System.Windows.Forms.TextBox();
            this.EatingTimeTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TicksLabel
            // 
            this.TicksLabel.AutoSize = true;
            this.TicksLabel.Location = new System.Drawing.Point(13, 13);
            this.TicksLabel.Name = "TicksLabel";
            this.TicksLabel.Size = new System.Drawing.Size(92, 13);
            this.TicksLabel.TabIndex = 0;
            this.TicksLabel.Text = "Ticks per second:";
            // 
            // CinemaTimeLabel
            // 
            this.CinemaTimeLabel.AutoSize = true;
            this.CinemaTimeLabel.Location = new System.Drawing.Point(13, 35);
            this.CinemaTimeLabel.Name = "CinemaTimeLabel";
            this.CinemaTimeLabel.Size = new System.Drawing.Size(86, 13);
            this.CinemaTimeLabel.TabIndex = 1;
            this.CinemaTimeLabel.Text = "Cinema duration:";
            // 
            // CleaningTimeLabel
            // 
            this.CleaningTimeLabel.AutoSize = true;
            this.CleaningTimeLabel.Location = new System.Drawing.Point(13, 57);
            this.CleaningTimeLabel.Name = "CleaningTimeLabel";
            this.CleaningTimeLabel.Size = new System.Drawing.Size(94, 13);
            this.CleaningTimeLabel.TabIndex = 2;
            this.CleaningTimeLabel.Text = "Cleaning Duration:";
            // 
            // EatTimeLabel
            // 
            this.EatTimeLabel.AutoSize = true;
            this.EatTimeLabel.Location = new System.Drawing.Point(13, 80);
            this.EatTimeLabel.Name = "EatTimeLabel";
            this.EatTimeLabel.Size = new System.Drawing.Size(83, 13);
            this.EatTimeLabel.TabIndex = 3;
            this.EatTimeLabel.Text = "Eating Duration:";
            // 
            // TicksTextBox
            // 
            this.TicksTextBox.Location = new System.Drawing.Point(117, 10);
            this.TicksTextBox.Name = "TicksTextBox";
            this.TicksTextBox.Size = new System.Drawing.Size(100, 20);
            this.TicksTextBox.TabIndex = 4;
            // 
            // CinemaTimeTextBox
            // 
            this.CinemaTimeTextBox.Location = new System.Drawing.Point(117, 32);
            this.CinemaTimeTextBox.Name = "CinemaTimeTextBox";
            this.CinemaTimeTextBox.Size = new System.Drawing.Size(100, 20);
            this.CinemaTimeTextBox.TabIndex = 5;
            // 
            // CleaningTimeTextBox
            // 
            this.CleaningTimeTextBox.Location = new System.Drawing.Point(117, 54);
            this.CleaningTimeTextBox.Name = "CleaningTimeTextBox";
            this.CleaningTimeTextBox.Size = new System.Drawing.Size(100, 20);
            this.CleaningTimeTextBox.TabIndex = 6;
            // 
            // EatingTimeTextBox
            // 
            this.EatingTimeTextBox.Location = new System.Drawing.Point(117, 77);
            this.EatingTimeTextBox.Name = "EatingTimeTextBox";
            this.EatingTimeTextBox.Size = new System.Drawing.Size(100, 20);
            this.EatingTimeTextBox.TabIndex = 7;
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 291);
            this.Controls.Add(this.EatingTimeTextBox);
            this.Controls.Add(this.CleaningTimeTextBox);
            this.Controls.Add(this.CinemaTimeTextBox);
            this.Controls.Add(this.TicksTextBox);
            this.Controls.Add(this.EatTimeLabel);
            this.Controls.Add(this.CleaningTimeLabel);
            this.Controls.Add(this.CinemaTimeLabel);
            this.Controls.Add(this.TicksLabel);
            this.Name = "SettingsForm";
            this.Text = "SettingsForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SettingsForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TicksLabel;
        private System.Windows.Forms.Label CinemaTimeLabel;
        private System.Windows.Forms.Label CleaningTimeLabel;
        private System.Windows.Forms.Label EatTimeLabel;
        private System.Windows.Forms.TextBox TicksTextBox;
        private System.Windows.Forms.TextBox CinemaTimeTextBox;
        private System.Windows.Forms.TextBox CleaningTimeTextBox;
        private System.Windows.Forms.TextBox EatingTimeTextBox;
    }
}