﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    partial class SettingsForm : Form
    {
        private MainForm _parent;
        private Hotel _hotel;

        /// <summary>
        /// When the form closes take all the fields that aren't empty and set the values to the new ones
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SettingsForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!TicksTextBox.Text.Equals(""))
            {
                int temp = 0;
                int.TryParse(TicksTextBox.Text , out temp);
                if (temp != 0)
                {
                    HotelEvents.HotelEventManager.HTE_Factor = temp;
                    _parent.TimeSync();
                }
            }
            if (!CinemaTimeTextBox.Text.Equals(""))
            {
                int temp = 0;
                int.TryParse(TicksTextBox.Text, out temp);
                if (temp != 0)
                {
                    _hotel.Cleaningtime= temp;
                }
            }
            if (!CleaningTimeTextBox.Text.Equals(""))
            {
                int temp = 0;
                int.TryParse(TicksTextBox.Text, out temp);
                if (temp != 0)
                {
                    _hotel.Cleaningtime = temp;
                }
            }
            if (!EatingTimeTextBox.Text.Equals(""))
            {
                int temp = 0;
                int.TryParse(TicksTextBox.Text, out temp);
                if (temp != 0)
                {
                    _hotel.Eatingtime = temp;
                }
            }
            _parent.PausePlay();
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parent">The MainForm that called this</param>
        /// <param name="hotel">The hotel it is changing the settigns for</param>
        public SettingsForm(MainForm parent, Hotel hotel)
        {
            InitializeComponent();
            _parent = parent;
            _hotel = hotel;

            TicksTextBox.Text = HotelEvents.HotelEventManager.HTE_Factor.ToString();
            CleaningTimeTextBox.Text = _hotel.Cleaningtime.ToString();
            EatingTimeTextBox.Text = _hotel.Eatingtime.ToString();
            CinemaTimeTextBox.Text = _hotel.Cinematime.ToString();

        }
    }
}
