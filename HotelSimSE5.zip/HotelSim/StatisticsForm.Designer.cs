﻿namespace HotelSim
{
    partial class StatisticsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StatisticsForm));
            this.AvailableRoomsLabel = new System.Windows.Forms.Label();
            this.tb1StarRooms = new System.Windows.Forms.TextBox();
            this.pb1Star = new System.Windows.Forms.PictureBox();
            this.pb2Star1 = new System.Windows.Forms.PictureBox();
            this.pb2star2 = new System.Windows.Forms.PictureBox();
            this.pb3star1 = new System.Windows.Forms.PictureBox();
            this.pb3star2 = new System.Windows.Forms.PictureBox();
            this.pb3star3 = new System.Windows.Forms.PictureBox();
            this.pb4star1 = new System.Windows.Forms.PictureBox();
            this.pb4star2 = new System.Windows.Forms.PictureBox();
            this.pb4star3 = new System.Windows.Forms.PictureBox();
            this.pb4star4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tb2StarRooms = new System.Windows.Forms.TextBox();
            this.tb3StarRooms = new System.Windows.Forms.TextBox();
            this.tb4StarRooms = new System.Windows.Forms.TextBox();
            this.tb5StarRooms = new System.Windows.Forms.TextBox();
            this.CustomersLabel = new System.Windows.Forms.Label();
            this.lbCustomers = new System.Windows.Forms.ListBox();
            this.lbCleaners = new System.Windows.Forms.ListBox();
            this.CleanerLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb1Star)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2Star1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2star2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // AvailableRoomsLabel
            // 
            this.AvailableRoomsLabel.AutoSize = true;
            this.AvailableRoomsLabel.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailableRoomsLabel.Location = new System.Drawing.Point(12, 9);
            this.AvailableRoomsLabel.Name = "AvailableRoomsLabel";
            this.AvailableRoomsLabel.Size = new System.Drawing.Size(128, 18);
            this.AvailableRoomsLabel.TabIndex = 1;
            this.AvailableRoomsLabel.Text = "Available Rooms:";
            // 
            // tb1StarRooms
            // 
            this.tb1StarRooms.Location = new System.Drawing.Point(148, 30);
            this.tb1StarRooms.Name = "tb1StarRooms";
            this.tb1StarRooms.ReadOnly = true;
            this.tb1StarRooms.Size = new System.Drawing.Size(29, 20);
            this.tb1StarRooms.TabIndex = 2;
            // 
            // pb1Star
            // 
            this.pb1Star.Image = ((System.Drawing.Image)(resources.GetObject("pb1Star.Image")));
            this.pb1Star.Location = new System.Drawing.Point(15, 30);
            this.pb1Star.Name = "pb1Star";
            this.pb1Star.Size = new System.Drawing.Size(20, 20);
            this.pb1Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1Star.TabIndex = 3;
            this.pb1Star.TabStop = false;
            // 
            // pb2Star1
            // 
            this.pb2Star1.Image = ((System.Drawing.Image)(resources.GetObject("pb2Star1.Image")));
            this.pb2Star1.Location = new System.Drawing.Point(15, 56);
            this.pb2Star1.Name = "pb2Star1";
            this.pb2Star1.Size = new System.Drawing.Size(20, 20);
            this.pb2Star1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2Star1.TabIndex = 4;
            this.pb2Star1.TabStop = false;
            // 
            // pb2star2
            // 
            this.pb2star2.Image = ((System.Drawing.Image)(resources.GetObject("pb2star2.Image")));
            this.pb2star2.Location = new System.Drawing.Point(41, 56);
            this.pb2star2.Name = "pb2star2";
            this.pb2star2.Size = new System.Drawing.Size(20, 20);
            this.pb2star2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2star2.TabIndex = 5;
            this.pb2star2.TabStop = false;
            // 
            // pb3star1
            // 
            this.pb3star1.Image = ((System.Drawing.Image)(resources.GetObject("pb3star1.Image")));
            this.pb3star1.Location = new System.Drawing.Point(15, 82);
            this.pb3star1.Name = "pb3star1";
            this.pb3star1.Size = new System.Drawing.Size(20, 20);
            this.pb3star1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3star1.TabIndex = 6;
            this.pb3star1.TabStop = false;
            // 
            // pb3star2
            // 
            this.pb3star2.Image = ((System.Drawing.Image)(resources.GetObject("pb3star2.Image")));
            this.pb3star2.Location = new System.Drawing.Point(41, 82);
            this.pb3star2.Name = "pb3star2";
            this.pb3star2.Size = new System.Drawing.Size(20, 20);
            this.pb3star2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3star2.TabIndex = 7;
            this.pb3star2.TabStop = false;
            // 
            // pb3star3
            // 
            this.pb3star3.Image = ((System.Drawing.Image)(resources.GetObject("pb3star3.Image")));
            this.pb3star3.Location = new System.Drawing.Point(67, 82);
            this.pb3star3.Name = "pb3star3";
            this.pb3star3.Size = new System.Drawing.Size(20, 20);
            this.pb3star3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3star3.TabIndex = 8;
            this.pb3star3.TabStop = false;
            // 
            // pb4star1
            // 
            this.pb4star1.Image = ((System.Drawing.Image)(resources.GetObject("pb4star1.Image")));
            this.pb4star1.Location = new System.Drawing.Point(15, 108);
            this.pb4star1.Name = "pb4star1";
            this.pb4star1.Size = new System.Drawing.Size(20, 20);
            this.pb4star1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4star1.TabIndex = 9;
            this.pb4star1.TabStop = false;
            // 
            // pb4star2
            // 
            this.pb4star2.Image = ((System.Drawing.Image)(resources.GetObject("pb4star2.Image")));
            this.pb4star2.Location = new System.Drawing.Point(41, 108);
            this.pb4star2.Name = "pb4star2";
            this.pb4star2.Size = new System.Drawing.Size(20, 20);
            this.pb4star2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4star2.TabIndex = 10;
            this.pb4star2.TabStop = false;
            // 
            // pb4star3
            // 
            this.pb4star3.Image = ((System.Drawing.Image)(resources.GetObject("pb4star3.Image")));
            this.pb4star3.Location = new System.Drawing.Point(67, 108);
            this.pb4star3.Name = "pb4star3";
            this.pb4star3.Size = new System.Drawing.Size(20, 20);
            this.pb4star3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4star3.TabIndex = 11;
            this.pb4star3.TabStop = false;
            // 
            // pb4star4
            // 
            this.pb4star4.Image = ((System.Drawing.Image)(resources.GetObject("pb4star4.Image")));
            this.pb4star4.Location = new System.Drawing.Point(93, 108);
            this.pb4star4.Name = "pb4star4";
            this.pb4star4.Size = new System.Drawing.Size(20, 20);
            this.pb4star4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4star4.TabIndex = 12;
            this.pb4star4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(93, 134);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(67, 134);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(41, 134);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(15, 134);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(20, 20);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(120, 134);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(20, 20);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 17;
            this.pictureBox5.TabStop = false;
            // 
            // tb2StarRooms
            // 
            this.tb2StarRooms.Location = new System.Drawing.Point(148, 56);
            this.tb2StarRooms.Name = "tb2StarRooms";
            this.tb2StarRooms.ReadOnly = true;
            this.tb2StarRooms.Size = new System.Drawing.Size(29, 20);
            this.tb2StarRooms.TabIndex = 18;
            // 
            // tb3StarRooms
            // 
            this.tb3StarRooms.Location = new System.Drawing.Point(148, 82);
            this.tb3StarRooms.Name = "tb3StarRooms";
            this.tb3StarRooms.ReadOnly = true;
            this.tb3StarRooms.Size = new System.Drawing.Size(29, 20);
            this.tb3StarRooms.TabIndex = 19;
            // 
            // tb4StarRooms
            // 
            this.tb4StarRooms.Location = new System.Drawing.Point(148, 108);
            this.tb4StarRooms.Name = "tb4StarRooms";
            this.tb4StarRooms.ReadOnly = true;
            this.tb4StarRooms.Size = new System.Drawing.Size(29, 20);
            this.tb4StarRooms.TabIndex = 20;
            // 
            // tb5StarRooms
            // 
            this.tb5StarRooms.Location = new System.Drawing.Point(148, 134);
            this.tb5StarRooms.Name = "tb5StarRooms";
            this.tb5StarRooms.ReadOnly = true;
            this.tb5StarRooms.Size = new System.Drawing.Size(29, 20);
            this.tb5StarRooms.TabIndex = 21;
            // 
            // CustomersLabel
            // 
            this.CustomersLabel.AutoSize = true;
            this.CustomersLabel.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersLabel.Location = new System.Drawing.Point(216, 9);
            this.CustomersLabel.Name = "CustomersLabel";
            this.CustomersLabel.Size = new System.Drawing.Size(89, 18);
            this.CustomersLabel.TabIndex = 22;
            this.CustomersLabel.Text = "Customers:";
            // 
            // lbCustomers
            // 
            this.lbCustomers.FormattingEnabled = true;
            this.lbCustomers.Location = new System.Drawing.Point(219, 30);
            this.lbCustomers.Name = "lbCustomers";
            this.lbCustomers.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lbCustomers.Size = new System.Drawing.Size(179, 251);
            this.lbCustomers.TabIndex = 23;
            // 
            // lbCleaners
            // 
            this.lbCleaners.FormattingEnabled = true;
            this.lbCleaners.Location = new System.Drawing.Point(15, 187);
            this.lbCleaners.Name = "lbCleaners";
            this.lbCleaners.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lbCleaners.Size = new System.Drawing.Size(162, 95);
            this.lbCleaners.TabIndex = 25;
            // 
            // CleanerLabel
            // 
            this.CleanerLabel.AutoSize = true;
            this.CleanerLabel.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CleanerLabel.Location = new System.Drawing.Point(12, 166);
            this.CleanerLabel.Name = "CleanerLabel";
            this.CleanerLabel.Size = new System.Drawing.Size(76, 18);
            this.CleanerLabel.TabIndex = 24;
            this.CleanerLabel.Text = "Cleaners:";
            // 
            // StatisticsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 300);
            this.Controls.Add(this.lbCleaners);
            this.Controls.Add(this.CleanerLabel);
            this.Controls.Add(this.lbCustomers);
            this.Controls.Add(this.CustomersLabel);
            this.Controls.Add(this.tb5StarRooms);
            this.Controls.Add(this.tb4StarRooms);
            this.Controls.Add(this.tb3StarRooms);
            this.Controls.Add(this.tb2StarRooms);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pb4star4);
            this.Controls.Add(this.pb4star3);
            this.Controls.Add(this.pb4star2);
            this.Controls.Add(this.pb4star1);
            this.Controls.Add(this.pb3star3);
            this.Controls.Add(this.pb3star2);
            this.Controls.Add(this.pb3star1);
            this.Controls.Add(this.pb2star2);
            this.Controls.Add(this.pb2Star1);
            this.Controls.Add(this.pb1Star);
            this.Controls.Add(this.tb1StarRooms);
            this.Controls.Add(this.AvailableRoomsLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "StatisticsForm";
            this.Text = "Statistics";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StatisticsForm_FormClosing);
            
            ((System.ComponentModel.ISupportInitialize)(this.pb1Star)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2Star1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2star2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3star3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4star4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label AvailableRoomsLabel;
        private System.Windows.Forms.TextBox tb1StarRooms;
        private System.Windows.Forms.PictureBox pb1Star;
        private System.Windows.Forms.PictureBox pb2Star1;
        private System.Windows.Forms.PictureBox pb2star2;
        private System.Windows.Forms.PictureBox pb3star1;
        private System.Windows.Forms.PictureBox pb3star2;
        private System.Windows.Forms.PictureBox pb3star3;
        private System.Windows.Forms.PictureBox pb4star1;
        private System.Windows.Forms.PictureBox pb4star2;
        private System.Windows.Forms.PictureBox pb4star3;
        private System.Windows.Forms.PictureBox pb4star4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox tb2StarRooms;
        private System.Windows.Forms.TextBox tb3StarRooms;
        private System.Windows.Forms.TextBox tb4StarRooms;
        private System.Windows.Forms.TextBox tb5StarRooms;
        private System.Windows.Forms.Label CustomersLabel;
        private System.Windows.Forms.ListBox lbCustomers;
        private System.Windows.Forms.ListBox lbCleaners;
        private System.Windows.Forms.Label CleanerLabel;
    }
}