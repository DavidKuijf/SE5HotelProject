﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelSim
{
    partial class StatisticsForm : Form
    {
        private Hotel _hotel;

        /// <summary>
        /// Updates the text on the form.
        /// </summary>
        public void DoUpdate()
        {
            // Titles, show the amount of available rooms and amount of customers present in the hotel.
            AvailableRoomsLabel.Text = $"Available Rooms:   ({_hotel.AvailableRooms.Count})";
            CustomersLabel.Text = $"Customers: ({_hotel.CustomerList.Count})";

            // Shows the amount of different star rooms present in the hotel.
            int oneStar = 0;
            int twoStar = 0;
            int threeStar = 0;
            int fourStar = 0;
            int fiveStar = 0;

            foreach (Room r in _hotel.AvailableRooms)
            {
                if (r.AreaType.Equals("1Star"))
                    oneStar++;
                if (r.AreaType.Equals("2stars"))
                    twoStar++;
                if (r.AreaType.Equals("3stars"))
                    threeStar++;
                if (r.AreaType.Equals("4stars"))
                    fourStar++;
                if (r.AreaType.Equals("5stars"))
                    fiveStar++;
            }

            tb1StarRooms.Text = oneStar.ToString();
            tb2StarRooms.Text = twoStar.ToString();
            tb3StarRooms.Text = threeStar.ToString();
            tb4StarRooms.Text = fourStar.ToString();
            tb5StarRooms.Text = fiveStar.ToString();

            lbCustomers.Items.Clear();

            // Shows all the customers in the hotel width their home and current goal.
            if (_hotel.CustomerList.Count != 0)
            {
                for (int i = _hotel.CustomerList.Count - 1; i >= 0; i--)
                {
                    Customer tempCustomer = (Customer)_hotel.CustomerList[i];

                    string wish;

                    if (tempCustomer.Wish != null)
                        wish = tempCustomer.Wish.EventType.ToString();
                    else
                        wish = "Idle";

                    string home = "";

                    if (tempCustomer.Home.AreaType.Equals("1Star"))
                        home = "1 Star";
                    if (tempCustomer.Home.AreaType.Equals("2stars"))
                        home = "2 Stars";
                    if (tempCustomer.Home.AreaType.Equals("3stars"))
                        home = "3 Stars";
                    if (tempCustomer.Home.AreaType.Equals("4stars"))
                        home = "4 Stars";
                    if (tempCustomer.Home.AreaType.Equals("5stars"))
                        home = "4 Stars";

                    lbCustomers.Items.Add($"Customer ({home}) [{wish}]");
                }
            }

            // Shows cleaners present in the hotel with their current goal.
            CleanerLabel.Text = $"Cleaners: ({_hotel.StaffList.Count})";

            lbCleaners.Items.Clear();

            foreach (Cleaner c in _hotel.StaffList)
            {
                string goal = "";

                if (c.Goal != null)
                {
                    if (c.Goal.AreaType.Equals("1Star"))
                        goal = "1 Star";
                    if (c.Goal.AreaType.Equals("2stars"))
                        goal = "2 Stars";
                    if (c.Goal.AreaType.Equals("3stars"))
                        goal = "3 Stars";
                    if (c.Goal.AreaType.Equals("4stars"))
                        goal = "4 Stars";
                    if (c.Goal.AreaType.Equals("5stars"))
                        goal = "4 Stars";
                    else
                        goal = c.Goal.AreaType.ToString();
                }
                else
                    goal = "Idle";

                lbCleaners.Items.Add($"Cleaner [{goal}]");
            }
        }

        /// <summary>
        /// Make sure the form is hidden instead of closed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StatisticsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="hotel">The parent hotel.</param>
        public StatisticsForm(Hotel hotel)
        {
            _hotel = hotel;
            InitializeComponent();
        }
    }
}
