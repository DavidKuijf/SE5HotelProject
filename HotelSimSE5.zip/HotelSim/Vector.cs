﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelSim
{
    public class Vector : IEquatable<Vector>
    {
        public int X { get; private set; }
        public int Y { get; private set; }

        public bool Equals(Vector obj)
        {
            return this.X == obj.X && this.Y == obj.Y;
        }

        public int GetHashCode(Vector obj)
        {
            return obj.X + obj.Y;
        }

        /// <summary>
        /// Hash code used for comparing two vectors.
        /// </summary>
        /// <returns>Hash codes.</returns>
        public override int GetHashCode()
        {
            var hashCode = 1861411795;
            hashCode = hashCode * -1521134295 + X.GetHashCode();
            hashCode = hashCode * -1521134295 + Y.GetHashCode();
            return hashCode;
        }

        /// <summary>
        /// Creates a vector representing a 2D location. 
        /// </summary>
        /// <param name="x">the value of X</param>
        /// <param name="y">the value of Y</param>
        public Vector(int x ,int y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
