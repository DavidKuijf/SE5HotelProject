﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using HotelSim;



namespace HotelSimUnittests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ExampleTestExpectFalse()
        {
            //Arrange
            Hotel hotel = null;
            //Act

            //Assert
            Assert.IsNull(hotel);
        }

        [TestMethod]
        public void EntityFactoryTestExpectNotNull()
        {
            //Arrange
            TestForm testForm = new TestForm();
            Hotel testHotel = new Hotel(testForm);
            RoomFactory testFactory = new RoomFactory(testHotel);
            //Act
            Entity testable = testFactory.GetEntity("Room");
            //Assert
            Assert.IsNotNull(testable);
        }

        [TestMethod]
        public void EntityFactoryTestExpecttrue()
        {
            //Arrange
            TestForm testForm = new TestForm();
            Hotel testHotel = new Hotel(testForm);
            CustomerFactory testFactory = new CustomerFactory(testHotel);
            //Act
            
            Entity cust2 = testFactory.GetEntity("Klant");

            //Assert
            if (cust2 is Customer)
            {
                
            }
            else
            {
                Assert.Fail();
            }
        }
    }
}
