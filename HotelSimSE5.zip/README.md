# Vragen voor klant
* Staan de groottes van wenskamers vast of kan dat per kamer verschillen?
* Kunnen klanten geen wens hebben en wat doen die dan?
* Wanneer worden kamers vies?
* Kunnen wenskamers ook vies worden?
* Heeft het schoonmaken een vaste duur of verschilt dat per kamer?
* Wat houd een CLEANING_EMERGENCY event in?
* Wat houd een EVACUATE event in?
* Wat houd een GODZILLA even in?:

* Wat houd een NEED_FOOD event in?
* Wat houd een GOTO_CINEMA event in?
* Wat houd een GOTO_FITNESS event in?
* Wat houd een STAR_CINEMA event in?
* Wat is het verschil tussen gast en gast1?
* Wat doen gasten zonder wens?
